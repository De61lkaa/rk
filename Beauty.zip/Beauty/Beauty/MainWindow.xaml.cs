﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Beauty
{
    public partial class MainWindow : Window
    {
        private BeautyEntities _context;
        private IQueryable<Service> _services;
        private bool IsAdminMode = false; // Флаг режима администратора

        public MainWindow()
        {
            InitializeComponent();
            LoadServices(); // Загрузка данных из базы
        }

        // Загрузка данных из базы
        private void LoadServices()
        {
            _context = new BeautyEntities();
            _services = _context.Service; // Инициализация запроса
            UpdateServiceList();
        }

        // Обновление списка услуг
        private void UpdateServiceList()
        {
            if (_context == null) return;

            // Применяем фильтрацию, если она задана
            var filteredServices = _services;

            // Применяем фильтрацию по скидке
            if (DiscountFilter != null)
            {
                var selectedFilter = (DiscountFilter.SelectedItem as ComboBoxItem)?.Content.ToString();
                switch (selectedFilter)
                {
                    case "0% - 5%":
                        filteredServices = filteredServices.Where(s => s.Discount >= 0 && s.Discount < 5);
                        break;
                    case "5% - 15%":
                        filteredServices = filteredServices.Where(s => s.Discount >= 5 && s.Discount < 15);
                        break;
                    case "15% - 30%":
                        filteredServices = filteredServices.Where(s => s.Discount >= 15 && s.Discount < 30);
                        break;
                    case "30% - 70%":
                        filteredServices = filteredServices.Where(s => s.Discount >= 30 && s.Discount < 70);
                        break;
                    case "70% - 100%":
                        filteredServices = filteredServices.Where(s => s.Discount >= 70 && s.Discount <= 100);
                        break;
                }
            }

            // Применяем поиск
            if (SearchBox != null && !string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                var searchText = SearchBox.Text.ToLower();
                filteredServices = filteredServices.Where(s => s.Title.ToLower().Contains(searchText) ||
                                                               s.Description.ToLower().Contains(searchText));
            }

            // Загружаем данные
            var services = filteredServices.ToList().Select(s => new
            {
                s.ID,
                s.Title,
                s.Cost,
                DiscountedCost = s.Discount.HasValue && s.Discount > 0
                    ? s.Cost * (decimal)(1 - (decimal)s.Discount / 100)
                    : s.Cost,
                DurationInMinutes = s.DurationInSeconds / 60,
                s.Description,
                s.Discount,
                MainImagePath = string.IsNullOrEmpty(s.MainImagePath)
                    ? "Images/placeholder.png"
                    : System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images", s.MainImagePath)
            }).ToList();

            // Устанавливаем данные в источник ListView
            if (ServiceListView != null)
            {
                ServiceListView.ItemsSource = services;
            }

            // Обновляем счётчик записей
            if (RecordCount != null)
            {
                RecordCount.Text = $"{services.Count} из {_context.Service.Count()}";
            }
        }

        // Сортировка по возрастанию стоимости
        private void SortAscending_Click(object sender, RoutedEventArgs e)
        {
            _services = _services.OrderBy(s => s.Cost);
            UpdateServiceList();
        }

        // Сортировка по убыванию стоимости
        private void SortDescending_Click(object sender, RoutedEventArgs e)
        {
            _services = _services.OrderByDescending(s => s.Cost);
            UpdateServiceList();
        }


        // Фильтрация по размеру скидки
        private void DiscountFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateServiceList();
        }

        // Поиск услуг по названию и описанию
        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateServiceList();
        }

        // Удаление услуги
        private void OnDeleteServiceClick(object sender, RoutedEventArgs e)
        {
            if (!IsAdminMode)
            {
                MessageBox.Show("Доступ запрещён. Вы не администратор!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var selectedService = ServiceListView.SelectedItem as Service;
            if (selectedService == null)
            {
                MessageBox.Show("Выберите услугу для удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (selectedService.ClientService.Any())
            {
                MessageBox.Show("Невозможно удалить услугу, так как есть связанные записи клиентов.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (selectedService.ServicePhoto.Any())
            {
                MessageBoxResult result = MessageBox.Show(
                    "Услуга содержит дополнительные фотографии. Удалить вместе с фотографиями?",
                    "Подтверждение",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    return;
            }

            _context.Service.Remove(selectedService);
            _context.SaveChanges();
            MessageBox.Show("Услуга удалена.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            UpdateServiceList();
        }


        // Обработчик для кнопки "Редактировать услугу"
        private void OnEditServiceClick(object sender, RoutedEventArgs e)
        {
            if (!IsAdminMode)
            {
                MessageBox.Show("Доступ запрещён. Вы не администратор!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Проверяем, выбрана ли строка
            var selectedItem = ServiceListView.SelectedItem;
            if (selectedItem == null)
            {
                MessageBox.Show("Выберите строку для редактирования.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Получаем ID услуги
            int id = (int)selectedItem.GetType().GetProperty("ID").GetValue(selectedItem);
            var selectedService = _context.Service.FirstOrDefault(s => s.ID == id);

            if (selectedService != null)
            {
                // Открываем окно редактирования
                var editWindow = new EditServiceWindow(selectedService);
                if (editWindow.ShowDialog() == true)
                {
                    UpdateServiceList();
                }
            }
            else
            {
                MessageBox.Show("Услуга не найдена.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }



        private void OnAdminLoginClick(object sender, RoutedEventArgs e)
        {
            // Проверяем введенный код администратора
            if (AdminCodeTextBox.Text == "0000") // Код администратора
            {
                IsAdminMode = true;
                AdminModeIndicator.Text = "Администраторский"; // Обновляем индикатор
                MessageBox.Show("Включен режим администратора.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);

                // Делаем панель администратора видимой
                AdminPanel.Visibility = Visibility.Visible;
            }
            else
            {
                IsAdminMode = false;
                AdminModeIndicator.Text = "Клиентский"; // Обновляем индикатор
                MessageBox.Show("Неверный код администратора!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

                // Скрываем панель администратора
                AdminPanel.Visibility = Visibility.Collapsed;
            }

            UpdateServiceList(); // Обновляем список услуг
        }

        private void OnAddServiceClick(object sender, RoutedEventArgs e)
        {
            if (!IsAdminMode)
            {
                MessageBox.Show("Доступ запрещён. Вы не администратор!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Открываем окно для добавления услуги
            var addWindow = new EditServiceWindow(null); // Передаём null для новой услуги
            if (addWindow.ShowDialog() == true)
            {
                UpdateServiceList(); // Обновляем список услуг после добавления
            }
        }

        private void OnAddClientClick(object sender, RoutedEventArgs e)
        {
            if (!IsAdminMode)
            {
                MessageBox.Show("Доступ запрещён. Вы не администратор!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var selectedItem = ServiceListView.SelectedItem;
            if (selectedItem == null)
            {
                MessageBox.Show("Выберите услугу для записи клиента.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int id = (int)selectedItem.GetType().GetProperty("ID").GetValue(selectedItem);
            var selectedService = _context.Service.FirstOrDefault(s => s.ID == id);

            if (selectedService != null)
            {
                var addClientWindow = new AddClientServiceWindow(selectedService);
                if (addClientWindow.ShowDialog() == true)
                {
                    MessageBox.Show("Клиент успешно записан!", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Услуга не найдена.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OnViewUpcomingRecordsClick(object sender, RoutedEventArgs e)
        {
            var window = new UpcomingRecordsWindow();
            window.ShowDialog();
        }


    }
}