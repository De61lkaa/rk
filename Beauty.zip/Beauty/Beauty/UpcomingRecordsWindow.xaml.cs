﻿using System;
using System.Linq;
using System.Timers;
using System.Windows;

namespace Beauty
{
    public partial class UpcomingRecordsWindow : Window
    {
        private readonly BeautyEntities _context;
        private readonly Timer _updateTimer;

        public UpcomingRecordsWindow()
        {
            InitializeComponent();
            _context = new BeautyEntities();

            LoadUpcomingRecords();

            // Установка таймера для обновления каждые 30 секунд
            _updateTimer = new Timer(30000);
            _updateTimer.Elapsed += (s, e) => Dispatcher.Invoke(LoadUpcomingRecords);
            _updateTimer.Start();
        }

        private void LoadUpcomingRecords()
        {
            // Получаем записи на сегодня и завтра
            var now = DateTime.Now;
            var tomorrow = now.Date.AddDays(2); // Сегодня и завтра

            var records = _context.ClientService
                .Where(cs => cs.StartTime >= now && cs.StartTime < tomorrow)
                .OrderBy(cs => cs.StartTime)
                .Select(cs => new
                {
                    ServiceTitle = cs.Service.Title,
                    ClientFullName = cs.Client.LastName + " " + cs.Client.FirstName + " " + cs.Client.Patronymic,
                    ClientEmail = cs.Client.Email,
                    ClientPhone = cs.Client.Phone,
                    StartTime = cs.StartTime
                })
                .ToList();

            // После получения данных рассчитываем оставшееся время
            var enrichedRecords = records.Select(cs => new
            {
                cs.ServiceTitle,
                cs.ClientFullName,
                cs.ClientEmail,
                cs.ClientPhone,
                cs.StartTime,
                TimeRemaining = CalculateTimeRemaining(cs.StartTime)
            }).ToList();

            RecordsDataGrid.ItemsSource = enrichedRecords;
        }

        private string CalculateTimeRemaining(DateTime startTime)
        {
            var timeDiff = startTime - DateTime.Now;
            if (timeDiff.TotalMinutes < 0)
                return "Запись началась";

            if (timeDiff.TotalHours < 1)
                return $"{timeDiff.Minutes} минут";

            return $"{(int)timeDiff.TotalHours} часов {timeDiff.Minutes} минут";
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            // Останавливаем таймер при закрытии окна
            _updateTimer.Stop();
            _updateTimer.Dispose();
        }
    }
}
