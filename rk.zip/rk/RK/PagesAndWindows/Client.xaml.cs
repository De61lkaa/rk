﻿using RK.BazaDan;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RK.PagesAndWindows
{
    /// <summary>
    /// Логика взаимодействия для Client.xaml
    /// </summary>
    public partial class Client : Page
    {
        private BazaDan.BazaDan bazadan;
        private ObservableCollection<BazaDan.Service> AllProducts;
        

        private ObservableCollection<BazaDan.Service> FilteredClients;
        private int PageSize = 10;

        
        private int CurrentPage = 1;
        public Client()
        {
            InitializeComponent();
            bazadan = new BazaDan.BazaDan();
            AllProducts = new ObservableCollection<BazaDan.Service>();  
            FilteredClients = new ObservableCollection<BazaDan.Service>();
            LoadClient();
            
        }
        public void LoadClient()
        {
            try
            {
                AllProducts = new ObservableCollection<BazaDan.Service>(bazadan.Service.ToList());
                FilteredClients = new ObservableCollection<BazaDan.Service>(AllProducts);
                UpdateClientGrid();
            }
            catch (Exception ex)
            {
                AllProducts = new ObservableCollection<BazaDan.Service>();
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private void UpdateClientGrid()
        {
            if (FilteredClients == null || ClientDataGrid == null || PageInfo == null)
            {
                return;  
            }

            var clientsToShow = FilteredClients
                .Skip((CurrentPage - 1) * PageSize)
                .Take(PageSize)
                .ToList();

            ClientDataGrid.ItemsSource = clientsToShow;
 
            var totalFiltered = FilteredClients?.Count ?? 0;
            var totalAll = AllProducts?.Count ?? 0;

            PageInfo.Text = $"{clientsToShow.Count} из {totalFiltered} (Всего: {totalAll})";
        }


        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFiltersAndSorting();

        }
        private void ApplyFiltersAndSorting()
        {
            if (AllProducts == null || AllProducts.Count == 0)
            {
                FilteredClients = new ObservableCollection<BazaDan.Service>();
                UpdateClientGrid();
                return;
            }

            var query = SearchBox.Text?.ToLower() ?? string.Empty;
            var selectedPriceRange = (PriceFilter.SelectedItem as ComboBoxItem)?.Tag?.ToString();
            var selectedSortOption = (SortComboBox.SelectedItem as ComboBoxItem)?.Tag?.ToString();
             
            var filteredList = AllProducts
                .Where(product =>
                    (string.IsNullOrEmpty(query) || product.Title.ToLower().Contains(query) || product.Title.ToLower().Contains(query))  &&
                    FilterByPrice((float)product.Cost, selectedPriceRange))
                .ToList();
             
            if (!string.IsNullOrEmpty(selectedSortOption))
            {
                filteredList = SortProducts(filteredList, selectedSortOption);
            }

            FilteredClients = new ObservableCollection<BazaDan.Service>(filteredList);
            UpdateClientGrid();
        }

        private List<BazaDan.Service> SortProducts(List<BazaDan.Service> products, string sortOption)
        {
            
            var sortStrategies = new Dictionary<string, Func<IEnumerable<BazaDan.Service>, IOrderedEnumerable<BazaDan.Service>>>
    {
        { "NameAsc", p => p.OrderBy(x => x.Title) },
        { "DurationDesc", p => p.OrderByDescending(x => x.DurationInSeconds) },
        { "CostAsc", p => p.OrderBy(x => x.Cost) },
        { "DiscountDesc", p => p.OrderByDescending(x => x.Discount) }
    };

            
            return sortStrategies.ContainsKey(sortOption)
                ? sortStrategies[sortOption](products).ToList()
                : products;
        }


        private void SortComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFiltersAndSorting();
        }

        private void PriceFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFiltersAndSorting();
        }

        


        private bool FilterByPrice(float price, string selectedPriceRange)
        {
            switch (selectedPriceRange)
            {
                case "меньше 500":
                    return price < 500;
                case "500-1000":
                    return price >= 500 && price <= 1000;
                case "1000-3000":
                    return price > 1000 && price <= 3000;
                
                default:
                    return true;  
            }
        }


        

         

        private void PreviousPage_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentPage > 1)
            {
                CurrentPage--;
                UpdateClientGrid();
            }
        }

        private void NextPage_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentPage * PageSize < FilteredClients.Count)
            {
                CurrentPage++;
                UpdateClientGrid();
            }
        }
    }
}
