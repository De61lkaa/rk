﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AutoServiceProduct.modul;
using AutoServiceProduct.Pages;

namespace AutoServiceProduct
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public class Helper
        {
            public static TradeEntities1 ent;
            public static TradeEntities1 GetContext()
            {
                if (ent == null)
                {
                    ent = new TradeEntities1();
                }
                return ent;
            }

        }
        public MainWindow()
        {
            InitializeComponent();
            FrmMain.Content = new PageAuthorization(FrmMain);

        }
    }
}
