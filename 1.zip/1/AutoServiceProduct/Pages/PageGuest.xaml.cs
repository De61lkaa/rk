﻿using AutoServiceProduct.modul;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static AutoServiceProduct.MainWindow;

namespace AutoServiceProduct.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageGuest.xaml
    /// </summary>
    public partial class PageGuest : Page
    {
        string fnd = "";
        int count = 0;
        int fullCount = 0;
        private Order currentOrder = null;
        public PageGuest()
        {
            InitializeComponent();
            Load();
        }
        public void Load()
        {
            var fullProductList = Helper.GetContext().Product.ToList();
            fullCount = fullProductList.Count();

            var filteredProducts = fullProductList
                .Where(product => product.ProductName.Contains(fnd))
                .ToList();


            if (cmbxDiscount.SelectedItem != null)
            {
                string selectedDiscount = (cmbxDiscount.SelectedItem as ComboBoxItem)?.Tag.ToString();
                if (selectedDiscount == "0-9")
                {
                    filteredProducts = filteredProducts.Where(p => p.Discount.value * 100 < 10).ToList();
                }
                else if (selectedDiscount == "10-14")
                {
                    filteredProducts = filteredProducts.Where(p => p.Discount.value * 100 >= 10 && p.Discount.value * 100 < 15).ToList();
                }
                else if (selectedDiscount == "15+")
                {
                    filteredProducts = filteredProducts.Where(p => p.Discount.value * 100 >= 15).ToList();
                }
            }


            if (cmbxSort.SelectedItem != null)
            {
                string selectedSort = (cmbxSort.SelectedItem as ComboBoxItem)?.Tag.ToString();
                if (selectedSort == "1")
                {
                    filteredProducts = filteredProducts.OrderBy(p => p.ProductName).ToList();
                }
                else if (selectedSort == "2")
                {
                    filteredProducts = filteredProducts.OrderByDescending(p => p.ProductCost).ToList();
                }
                else if (selectedSort == "3")
                {
                    filteredProducts = filteredProducts.OrderBy(p => p.ProductCost).ToList();
                }
            }

            count = filteredProducts.Count();
            DGProduct.ItemsSource = filteredProducts;
            txbkfull.Text = $"{count} из {fullCount}";
           
          
        }

        private void DGProduct_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            var product = (Product)e.Row.DataContext;
            int discountPercentage = Convert.ToInt32(product.Discount.value * 100);


            e.Row.Background = discountPercentage > 15 ? Brushes.LightGreen : Brushes.Transparent;

            int discountedPrice = (int)(product.ProductCost - (product.ProductCost * discountPercentage / 100));
            product.messCost = discountedPrice > 0 ? $"{discountedPrice} руб." : "Цена недоступна";
            product.messDiscount = $"{discountPercentage}%";
        }

        private void txbxSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            fnd = txbxSearch.Text;
            Load();
        }

        private void cmbxDiscount_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Load();
        }

        private void cmbxSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Load();
        }

       

        private void AddToOrder(Product selectedProduct)
        {
            if (currentOrder == null)
            {

                currentOrder = new Order
                {
                    OrderDate = DateTime.Now,
                    OrderStatus = "Новый",
                    OrderPickupPoint = "Точка выдачи по умолчанию",
                    OrderProduct = new List<OrderProduct>(),
                    OrderDeliveryDate = DateTime.Now.AddDays(3)
                };


                Helper.GetContext().Order.Add(currentOrder);

                Helper.GetContext().SaveChanges();
            }

            var existingProduct = currentOrder.OrderProduct
                .FirstOrDefault(op => op.ProductArticleNumber == selectedProduct.ProductArticleNumber);

            if (existingProduct == null)
            {
                var newOrderProduct = new OrderProduct
                {
                    ProductArticleNumber = selectedProduct.ProductArticleNumber,
                    Count = 1,
                    OrderID = currentOrder.OrderID
                };


                Helper.GetContext().OrderProduct.Add(newOrderProduct);
                MessageBox.Show($"Товар добавлен: {newOrderProduct.ProductArticleNumber}");
            }

            else
            {
                existingProduct.Count++;
            }

            try
            {

                Helper.GetContext().SaveChanges();
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var entityValidationErrors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in entityValidationErrors.ValidationErrors)
                    {
                        MessageBox.Show($"Ошибка валидации: {validationError.PropertyName}: {validationError.ErrorMessage}");
                    }
                }
            }
            catch (DbUpdateException dbEx)
            {
                var innerException = dbEx.InnerException != null
       ? dbEx.InnerException.Message
       : "Неизвестная ошибка.";
                MessageBox.Show($"Ошибка обновления базы данных: {innerException}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}");
            }


           
            
        }

    }
}
