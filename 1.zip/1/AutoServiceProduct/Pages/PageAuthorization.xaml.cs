﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using static AutoServiceProduct.MainWindow;
using Brush = System.Drawing.Brush;
using Color = System.Drawing.Color;

namespace AutoServiceProduct.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAuthorization.xaml
    /// </summary>
    public partial class PageAuthorization : Page
    {
        private DispatcherTimer timer;
        private DateTime timeBlock;
        int chance = 0;
        string capchaText;

        public PageAuthorization(Frame FrmMain)
        {
            InitializeComponent();
        }
        private void generateCapcha(int chance)
        {
            
            txbxCapchaDisplay.Visibility = Visibility.Visible; 
            txbxCapchaInput.Visibility = Visibility.Visible; 


            string capch = GenCap(4); 
            capchaText = capch; 

            
            txbxCapchaDisplay.Text = capch; 

        }

        private void blockUnblock(bool bl)
        {
            txbxLogin.IsEnabled = bl;
            pswbPassword.IsEnabled = bl;
            btnOK.IsEnabled = bl;
            txbxCapchaDisplay.IsEnabled = bl;
            txbxCapchaInput.IsEnabled = bl;
        }

        private void timerStart(int timeTimer)
        {
            txbkTimer.Visibility = Visibility.Visible;
            timeBlock = DateTime.Now.AddSeconds(timeTimer);
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(100);
            timer.Tick += Time_Tick;
            timer.Start();
        }

        private void Time_Tick(object sender, EventArgs e)
        {
            TimeSpan updateTime = timeBlock - DateTime.Now;
            txbkTimer.Text = $"Блокировка: {string.Format("{0:F0}", updateTime.TotalSeconds)} сек.";
            if (DateTime.Now >= timeBlock)
            {
                timer.Stop();
                blockUnblock(true);
                txbkTimer.Visibility = Visibility.Hidden;
            }
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if (chance == 0)
            {
                var auth = Helper.GetContext().User.FirstOrDefault(user => user.UserLogin == txbxLogin.Text && user.UserPassword == pswbPassword.Password);
                if (auth != null)
                {
                    NavigationService.Navigate(new PageAdmin(auth)); 
                }
                else
                {
                    chance++;
                    generateCapcha(chance);
                }
            }

            else
            {
                if (txbxCapchaInput.Text == capchaText)
                {
                    chance = 0;
                    var auth = Helper.GetContext().User.FirstOrDefault(user => user.UserLogin == txbxLogin.Text && user.UserPassword == pswbPassword.Password);
                }
                else 
                {
                    generateCapcha(chance);
                    
                    blockUnblock(false);
                    timerStart(10);
                }
                
               
            }
        }

        public string GenCap(int len)
        {
            string capch = null;
            Random rnd = new Random();
            for (int i = 0; i < len; i++)
            {
                int rand = rnd.Next(0, 3);
                switch (rand)
                {
                    case 0:
                        char x = (char)rnd.Next('A', 'Z' + 1);
                        capch = capch + Convert.ToString(x);
                        break;
                    case 1:
                        x = (char)rnd.Next('a', 'z' + 1);
                        capch = capch + Convert.ToString(x);
                        break;
                    case 2:
                        x = (char)rnd.Next('0', '9' + 1);
                        capch = capch + Convert.ToString(x);
                        break;

                }
            }
            return capch;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new PageGuest());
        }
    }
}
