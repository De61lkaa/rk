﻿using AutoServiceProduct.modul;
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using iTextSharp.text;
using iTextSharp.text.pdf;
using static AutoServiceProduct.MainWindow;


namespace AutoServiceProduct.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrderDetailsWindow.xaml
    /// </summary>
    public partial class OrderDetailsWindow : Window
    {
        private Order _order;
        public OrderDetailsWindow(Order order)
        {
            InitializeComponent();
            _order = order;

            lvOrderDetails.ItemsSource = _order.OrderProduct;
            tbOrderNumber.Text = _order.OrderID.ToString();

            UpdateOrderSummary();
            if (!string.IsNullOrEmpty(_order.OrderClient))
            {
                tbClientInfo.Text = $"Клиент: {_order.OrderClient}";
            }

            cbPickupPoints.SelectedItem = _order.OrderPickupPoint;
        }
        private void UpdateOrderSummary()
        {
            decimal totalPrice = _order.CalculateTotalPrice();
            decimal totalDiscount = _order.CalculateTotalDiscount();
            tbOrderSummary.Text = $"Сумма заказа: {totalPrice}\nСумма скидки: {totalDiscount}";
        }

        private void DeleteSelectedProduct_Click(object sender, RoutedEventArgs e)
        {
            if (lvOrderDetails.SelectedItem is OrderProduct selectedProduct)
            {
                Helper.GetContext().OrderProduct.Remove(selectedProduct);
                Helper.GetContext().SaveChanges();
                lvOrderDetails.Items.Refresh();
                UpdateOrderSummary();
            }
        }

        private void cbPickupPoints_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbPickupPoints.SelectedItem is ComboBoxItem selectedItem)
            {
                _order.OrderPickupPoint = selectedItem.Content.ToString();
                Helper.GetContext().SaveChanges();
            }
        }

        private void SaveReceipt_Click(object sender, RoutedEventArgs e)
        {
            SavePdf();
        }

        private void SavePdf()
        {
            string fileName = $"Order_{_order.OrderID}.pdf"; // Имя файла
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                FileName = fileName,
                Filter = "PDF files (*.pdf)|*.pdf",
                DefaultExt = "pdf"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                using (FileStream fs = new FileStream(saveFileDialog.FileName, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    Document document = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(document, fs);
                    document.Open();

                    // Заголовок документа
                    document.Add(new Paragraph("Talon", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 20)));
                    document.Add(new Paragraph($"Date: {DateTime.Now:dd/MM/yyyy}", FontFactory.GetFont(FontFactory.HELVETICA, 12)));
                    document.Add(new Paragraph($"Number Order: {_order.OrderID}", FontFactory.GetFont(FontFactory.HELVETICA, 12)));
                    document.Add(new Paragraph("Sostav:", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14)));

                    // Перечисление всех позиций заказа
                    foreach (var product in _order.OrderProduct)
                    {
                        document.Add(new Paragraph($"-Product: {product.Product.ProductName}", FontFactory.GetFont(FontFactory.HELVETICA, 12)));
                        document.Add(new Paragraph($"Count: {product.Count}, Цена: {product.ProductCost:0.00} руб.", FontFactory.GetFont(FontFactory.HELVETICA, 12)));
                    }

                    decimal totalPrice = _order.CalculateTotalPrice();
                    decimal totalDiscount = _order.CalculateTotalDiscount();
                    document.Add(new Paragraph($"Order Price: {totalPrice:0.00} руб.", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 12)));
                    document.Add(new Paragraph($"Sale Sum: {totalDiscount:0.00} руб.", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 12)));

                    // Генерация кода получения
                    Random random = new Random();
                    int code = random.Next(100, 999);
                    document.Add(new Paragraph("Order Code:", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14)));
                    document.Add(new Paragraph(code.ToString(), FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 16)));

                    // Определение срока доставки
                    int itemCount = _order.OrderProduct.Sum(p => p.Count);
                    string deliveryTime = itemCount > 3 ? "3 дня" : "6 дней";
                    document.Add(new Paragraph($"DateDostavki: {deliveryTime}", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 12)));

                    if (!string.IsNullOrEmpty(_order.OrderClient))
                    {
                        document.Add(new Paragraph($"Klient: {_order.OrderClient}", FontFactory.GetFont(FontFactory.HELVETICA, 12)));
                    }

                    // Закрытие документа
                    document.Close();
                    writer.Close();
                }

                MessageBox.Show("Талон успешно сохранён в PDF!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

    }
}