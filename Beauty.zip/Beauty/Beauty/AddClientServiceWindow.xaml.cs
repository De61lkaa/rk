﻿using System;
using System.Linq;
using System.Windows;

namespace Beauty
{
    public partial class AddClientServiceWindow : Window
    {
        private readonly BeautyEntities _context;
        private readonly Service _selectedService;

        public AddClientServiceWindow(Service service)
        {
            InitializeComponent();
            _context = new BeautyEntities();
            _selectedService = service;

            LoadServiceData();
            LoadClients();
        }

        // Загрузка данных услуги
        private void LoadServiceData()
        {
            ServiceName.Text = _selectedService.Title;
            ServiceDuration.Text = $"{_selectedService.DurationInSeconds / 60} минут";
        }

        // Загрузка списка клиентов
        private void LoadClients()
        {
            var clients = _context.Client
                .Select(c => new
                {
                    c.ID,
                    FullName = c.LastName + " " + c.FirstName + " " + c.Patronymic // Составляем полное имя
                })
                .ToList();

            ClientComboBox.ItemsSource = clients;
            ClientComboBox.DisplayMemberPath = "FullName"; // Указываем отображаемое имя
            ClientComboBox.SelectedValuePath = "ID"; // Указываем, что идентификатор - это ID
        }


        // Сохранение записи клиента
        private void OnSaveClick(object sender, RoutedEventArgs e)
        {
            if (ClientComboBox.SelectedItem == null || string.IsNullOrWhiteSpace(StartTimeBox.Text) || DatePicker.SelectedDate == null)
            {
                MessageBox.Show("Заполните все поля!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Проверка корректности времени
            if (!TimeSpan.TryParse(StartTimeBox.Text, out TimeSpan startTime))
            {
                MessageBox.Show("Введите корректное время начала (формат ЧЧ:ММ)!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Вычисляем время окончания
            var duration = TimeSpan.FromSeconds(_selectedService.DurationInSeconds);
            var endTime = startTime + duration;

            // Создаём запись клиента
            var clientService = new ClientService
            {
                ClientID = (int)ClientComboBox.SelectedValue,
                ServiceID = _selectedService.ID,
                StartTime = DatePicker.SelectedDate.Value + startTime,
                Comment = CommentBox.Text // Если есть поле для комментариев
            };

            // Сохраняем в базу данных
            _context.ClientService.Add(clientService);
            _context.SaveChanges();

            MessageBox.Show("Запись успешно добавлена!", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            DialogResult = true;
            Close();
        }

        // Отмена добавления записи
        private void OnCancelClick(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
