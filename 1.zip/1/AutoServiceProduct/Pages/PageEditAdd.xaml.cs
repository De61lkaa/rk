﻿using AutoServiceProduct.modul;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static AutoServiceProduct.MainWindow;

namespace AutoServiceProduct.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageEditAdd.xaml
    /// </summary>
    public partial class PageEditAdd : Page
    {
        private Product _product;
        private bool _isEditMode;
        public PageEditAdd(Product product = null)
        {
            InitializeComponent();
            _product = product;
            _isEditMode = product != null;
            LoadComboBoxData();
            if (_isEditMode)
            {
                LoadProductData();
                btnDelete.Visibility = Visibility.Visible; 
                txtArticle.IsReadOnly = true; 
            }
        }
        private void LoadComboBoxData()
        {
            // Создаем список фиксированных категорий
            var categories = new List<string>
            {
            "Аксессуары",
            "Автозапчасти",
            "Автосервис",
            "Съемники подшипников",
            "Ручные инструменты",
            "Зарядные устройства"
            };

            // Привязываем список категорий к ComboBox
            cmbCategory.ItemsSource = categories;

            // Если в режиме редактирования, устанавливаем текущее значение
            if (_isEditMode)
            {
                cmbCategory.SelectedItem = _product.ProductCategory; // Убедитесь, что ProductCategory хранит строковые значения
            }

            // Загрузка единиц измерения из базы данных
            var units = Helper.GetContext().UnitsOfMear.ToList(); // Замените 'UnitsOfMear' на вашу таблицу единиц измерения
            cmbUnit.ItemsSource = units;
            cmbUnit.DisplayMemberPath = "Type"; // Замените 'UnitName' на название свойства, которое вы хотите показать
            cmbUnit.SelectedValuePath = "idUnit"; // Замените 'UnitId' на идентификатор вашей единицы измерения

            // Если в режиме редактирования, устанавливаем текущее значение
            if (_isEditMode)
            {
                cmbUnit.SelectedValue = _product.ProductUnit; // Убедитесь, что ProductUnit соответствует идентификатору в базе данных
            }
        }
        private void LoadProductData()
        {
            txtArticle.Text = _product.ProductArticleNumber;
            txtName.Text = _product.ProductName;
            txtQuantity.Text = _product.ProductQuantityInStock.ToString();
            txtCost.Text = _product.ProductCost.ToString();
            txtCurrentDiscount.Text = (_product.ProductDiscountAmount ?? 0).ToString();
            txtMaxDiscount.Text = _product.ProductMaxDiscount.ToString();
            txtProvider.Text = _product.ProductProvider;
            txtDescription.Text = _product.ProductDescription;
            
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            
            if (!decimal.TryParse(txtCost.Text, out decimal cost) || cost < 0)
            {
                MessageBox.Show("Цена не может быть отрицательной или не числом.");
                return;
            }

            if (!int.TryParse(txtQuantity.Text, out int quantity) || quantity < 0)
            {
                MessageBox.Show("Количество не может быть отрицательным или не числом.");
                return;
            }

            if (_isEditMode)
            {
               
                _product.ProductName = txtName.Text;
                _product.ProductQuantityInStock = quantity;
                _product.ProductCost = cost;
                _product.ProductDiscountAmount = int.Parse(txtCurrentDiscount.Text);
                _product.ProductMaxDiscount = byte.Parse(txtMaxDiscount.Text);
                _product.ProductProvider = txtProvider.Text;
                _product.ProductDescription = txtDescription.Text;
            }
            else
            {
                
                Product newProduct = new Product
                {
                    ProductArticleNumber = txtArticle.Text, 
                    ProductName = txtName.Text,
                    ProductQuantityInStock = quantity,
                    ProductCost = cost,
                    ProductDiscountAmount = int.Parse(txtCurrentDiscount.Text),
                    ProductMaxDiscount = byte.Parse(txtMaxDiscount.Text),
                    ProductProvider = txtProvider.Text,
                    ProductDescription = txtDescription.Text,
                   
                };

                
                Helper.GetContext().Product.Add(newProduct);
            }

            Helper.GetContext().SaveChanges();
            MessageBox.Show("Данные успешно сохранены!");
           
            NavigationService.GoBack(); 
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите удалить этот товар?", "Подтверждение удаления", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                Helper.GetContext().Product.Remove(_product);
                Helper.GetContext().SaveChanges();
                MessageBox.Show("Товар успешно удалён.");
              
                NavigationService.GoBack();
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void btnLoadImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                InitialDirectory = @"C:\Users\Рома\Desktop\AutoServiceProduct\AutoServiceProduct\image\",
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp" 
            };

            if (openFileDialog.ShowDialog() == true)
            {
                
                string imagePath = openFileDialog.FileName;
                string imageName = System.IO.Path.GetFileName(imagePath);
                imagePath = imageName;

                MessageBox.Show("Изображение успешно загружено: " + imagePath);
            }
        }
    }
}