﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace Beauty
{
    public partial class EditServiceWindow : Window
    {
        private Service _service;
        private BeautyEntities _context;
        private List<ServicePhoto> _photos; // Локальный список фотографий

        public EditServiceWindow(Service service)
        {
            InitializeComponent();
            _context = new BeautyEntities();
            _service = service ?? new Service();
            _photos = _service.ServicePhoto.ToList(); // Загружаем существующие фотографии
            LoadServiceData();
        }

        private void LoadServiceData()
        {
            // Загрузка основных данных услуги
            if (_service.ID > 0)
            {
                IdBox.Text = _service.ID.ToString();
                TitleBox.Text = _service.Title;
                CostBox.Text = _service.Cost.ToString();
                DurationBox.Text = _service.DurationInSeconds.ToString();
                DescriptionBox.Text = _service.Description;
                DiscountBox.Text = _service.Discount?.ToString() ?? "0";

                // Основное изображение
                if (!string.IsNullOrEmpty(_service.MainImagePath) && File.Exists(_service.MainImagePath))
                {
                    PreviewImage.Source = new BitmapImage(new Uri(_service.MainImagePath, UriKind.Absolute));
                }
            }
            else
            {
                IdBox.Text = "Автоматически";
            }

            // Загружаем фотографии
            PhotosList.ItemsSource = _photos;
        }

        private void OnAddPhotoClick(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "Image files (*.jpg, *.jpeg, *.png)|*.jpg;*.jpeg;*.png"
            };

            if (dialog.ShowDialog() == true)
            {
                var sourcePath = dialog.FileName;
                var fileName = Path.GetFileName(sourcePath);
                var destinationPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images", fileName);

                try
                {
                    File.Copy(sourcePath, destinationPath, true); // Копируем файл в папку проекта
                    var newPhoto = new ServicePhoto
                    {
                        ServiceID = _service.ID,
                        PhotoPath = destinationPath
                    };

                    _photos.Add(newPhoto); // Добавляем в локальный список
                    PhotosList.Items.Refresh(); // Обновляем отображение
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении изображения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void OnDeletePhotoClick(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;

            if (button?.Tag is int photoId) // Проверяем, был ли передан ID фотографии
            {
                var photoToRemove = _photos.FirstOrDefault(p => p.ID == photoId);

                if (photoToRemove != null)
                {
                    try
                    {
                        // Убираем изображение из интерфейса
                        if (PreviewImage.Source != null)
                        {
                            PreviewImage.Source = null;
                            GC.Collect();
                            GC.WaitForPendingFinalizers(); // Ожидаем завершения работы сборщика мусора
                        }

                        // Удаляем файл с диска
                        var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images", photoToRemove.PhotoPath);
                        if (File.Exists(filePath))
                        {
                            File.Delete(filePath);
                        }

                        // Удаляем из базы данных
                        if (photoToRemove.ID > 0)
                        {
                            if (_context.Entry(photoToRemove).State == System.Data.Entity.EntityState.Detached)
                            {
                                _context.ServicePhoto.Attach(photoToRemove);
                            }
                            _context.ServicePhoto.Remove(photoToRemove);
                            _context.SaveChanges();
                        }

                        // Удаляем из локального списка
                        _photos.Remove(photoToRemove);
                        PhotosList.ItemsSource = null;
                        PhotosList.ItemsSource = _photos;

                        MessageBox.Show("Фотография успешно удалена.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении файла изображения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }


        private void OnLoadImageClick(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "Image files (*.jpg, *.jpeg, *.png)|*.jpg;*.jpeg;*.png"
            };

            if (dialog.ShowDialog() == true)
            {
                var sourcePath = dialog.FileName;
                var fileName = Path.GetFileName(sourcePath);
                var destinationPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images", fileName);

                try
                {
                    // Копируем файл в директорию проекта
                    File.Copy(sourcePath, destinationPath, true);

                    // Создаем временный поток для загрузки изображения
                    BitmapImage bitmap = null;
                    using (var stream = new FileStream(destinationPath, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        bitmap = new BitmapImage();
                        bitmap.BeginInit();
                        bitmap.CacheOption = BitmapCacheOption.OnLoad; // Загружаем изображение полностью в память
                        bitmap.StreamSource = stream;
                        bitmap.EndInit();
                        bitmap.Freeze(); // "Замораживаем" объект для безопасного использования в UI
                    }

                    // Устанавливаем изображение в интерфейс
                    PreviewImage.Source = bitmap;

                    // Добавляем фотографию в локальный список
                    var newPhoto = new ServicePhoto
                    {
                        ServiceID = _service.ID,
                        PhotoPath = fileName
                    };

                    _photos.Add(newPhoto);

                    // Если услуга уже существует, сохраняем в базу
                    if (_service.ID > 0)
                    {
                        _context.ServicePhoto.Add(newPhoto);
                        _context.SaveChanges();
                    }

                    PhotosList.ItemsSource = null;
                    PhotosList.ItemsSource = _photos;

                    MessageBox.Show("Фотография успешно добавлена.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении изображения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }




        private void OnSaveClick(object sender, RoutedEventArgs e)
        {
            // Сохраняем основные данные услуги
            _service.Title = TitleBox.Text;
            _service.Cost = decimal.Parse(CostBox.Text);
            _service.DurationInSeconds = int.Parse(DurationBox.Text);
            _service.Description = DescriptionBox.Text;
            _service.Discount = double.TryParse(DiscountBox.Text, out var discount) ? (double?)discount : null;

            if (_service.ID == 0)
            {
                _context.Service.Add(_service);
            }

            // Сохраняем фотографии
            foreach (var photo in _photos)
            {
                if (photo.ID == 0)
                {
                    _context.ServicePhoto.Add(photo);
                }
            }

            _context.SaveChanges();
            DialogResult = true;
            Close();
        }

        private void OnCancelClick(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
